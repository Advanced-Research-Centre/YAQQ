
def run():
    print("\nThank you for using YAQQ.")